
    <div class="col-xs-12 col-sm-9 ply_rv">
        
        <div class="ply_rv_dv">
        
             <?php
             if (!isset($_SESSION['id']) || (isset($_SESSION['id']) && $profile_id != $_SESSION['id'])) {
                //  echo $_SESSION['id'];
                // echo $user_type;
                if($_SESSION["user_type"]==2 or $_SESSION["user_type"]==3 or $_SESSION["user_type"]==1)
                {
                    ?>
                    
                        <form method="POST">
                            
                    <!--<form method="POST">-->
                    <!--    <button name="endorse">Endorse this player</button>-->
                        
                    <?php
                    $query4="SELECT * from pitch_endorsement_type";
                    if (!$result4=$db->query($query4)) {
                            echo("Error description: " . $db -> error);
                    }    
                    $looping=$result4->num_rows();
                    // echo $looping;
                    $loopingfinal=(int)$looping/3;
                    // echo $loopingfinal;
                    $row4=$result4->result_array();
                    echo "<br>";
                    ?>
                    <div class="row">
                    <?php
                    foreach ($row4 as $rows4)
                    {
                        // echo $rows4["endorsement_name"].", ";
                        ?>
                        <div class="col-md-4">
                            <!--<div class="checkbox">-->
                                <label style="font-weight:400;">
                            <input type="checkbox" value="<?php 
                            echo $rows4["id"];
                            ?>" name='<?php
                            echo $rows4["id"];
                            ?>'><?php 
                            echo "&nbsp;".$rows4["endorsement_name"]."<br>";
                            ?>
                            </label>
                            <!--</div>-->
                            </div>
                        <?php
                    }
                    ?>
                    </div>
                    <br>
                    <label>Enter name of field:</label>
                        <input type="text" name="customField" placeholder="Custom Endorse" class="form-control">
                        <br>
                        <center><button name="endorse" class="btn btn-primary" style="height:30%;width:30%;">Endorse this player</button></center><br>
                    <?php
                    ?>
                    </form>
                    
                    <!--<div class="col-md-6">abcd</div>-->
                    
                    <?php
                    if(isset($_POST["endorse"]))
                    {
                        
                        $query5="SELECT * from pitch_endorsement_type";
                        if (!$result5=$db->query($query5)) {
                                echo("Error description: " . $db -> error);
                        }    
                        $row5=$result5->result_array();
                        foreach ($row5 as $rows5)
                        {
                            // var_dump($rows5);
                            
                            $postname1=$rows5["id"];
                            $postname=$rows5["endorsement_name"];
                            $coachid=$_SESSION["id"];
                            if(isset($_POST[$postname1]))
                            {
                                $endorseid=$rows5["id"];
                                // echo $endorseid; 
                                $query7="SELECT * from pitch_endorsement where user_id=$profile_id and endorsement_id=$endorseid";
                                
                                if (!$result7=$db->query($query7)) {
                                    echo("Error description: " . $db -> error);
                                }    
                                if ($result7->num_rows() == 0) {
				                    $query6="INSERT INTO pitch_endorsement (user_id,endorsement_id,endorsement_count,endorsment_user_id) VALUES($profile_id,$endorseid,1,$coachid)" ;
				                    if ($db->query($query6) === TRUE) 
				                    {
                                        // echo "New record created successfully";
                                        ?>
                                                <div class="container">
                                                  
                                                  <div class="alert alert-success">
                                                    <strong>Success!</strong> Player endorsed successfully in <?php echo $postname; ?>
                                                  </div>
                                                </div>
                                        <?php
                                        $query12="UPDATE pitch_user set endorsement_count = endorsement_count+1 where id=$profile_id";
                                                if ($db->query($query12)) 
        				                        {
        				                        
        				                        }
        				                        else 
                                                {
                                                    echo "Error: " . $db->error;
                                                }
                                    }    
                                    else 
                                    {
                                        echo "Error: " . $db->error;
                                    }
				                }
				                else
				                {
				                    // $query8="SELECT * from pitch_endorsement_type where user_id=$profile_id and ";
				                    $row7=$result7->result_array();
				                    // var_dump($row4);
                                    foreach ($row7 as $rows7)
                                    {
                                        // var_dump($rows7);
                                        
                                        $endcount=$rows7["endorsement_count"];
                                        $endcountuser=$rows7["endorsment_user_id"];
                                        $enduserarray=explode(",",$rows7["endorsment_user_id"]);
                                        $k=0;
                                        $check=true;
                                        while($k<sizeof($enduserarray))
                                        {
                                            if($enduserarray[$k]==$_SESSION["id"])
                                            {
                                                $check=false;
                                            }
                                            $k++;
                                        }
                                        if($check)
                                        {
                                            $query6="UPDATE pitch_endorsement set endorsement_count=".$endcount."+1, endorsment_user_id='$endcountuser,$coachid' where user_id=$profile_id AND endorsement_id=$endorseid";
                                            
                                            echo $query6;
        				                    if ($db->query($query6)) 
        				                    {
                                                // echo "New record created successfully";
                                                ?>
                                                <div class="container">
                                                  
                                                  <div class="alert alert-success">
                                                    <strong>Success!</strong> Player endorsed successfully in <?php echo $postname; ?>
                                                  </div>
                                                </div>
                                                <?php
                                                $query12="UPDATE pitch_user set endorsement_count = endorsement_count+1 where id=$profile_id";
                                                if ($db->query($query12)) 
        				                        {
        				                        
        				                        }
        				                        else 
                                                {
                                                    echo "Error: " . $db->error;
                                                }
                                            }    
                                            else 
                                            {
                                                echo "Error: " . $db->error;
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                            <div class="container">
                                                <div class="alert alert-danger">
                                                    <strong>Error:</strong> This Player is already endorsed by you in <?php echo $postname; ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
				                    // echo "here";
				                    
				                }
                                
                            }
                        }
                        if(isset($_POST["customField"]) and $_POST["customField"]!="")
                        {
                            $customfield=$_POST["customField"];
                            $query13="INSERT INTO pitch_endorsement_type(endorsement_name) values('$customfield')";
                            if ($db->query($query13)) 
        				    {
        				        $query15="SELECT id from pitch_endorsement_type where endorsement_name='$customfield'";
        				        if ($result15=$db->query($query15)) 
        				        {
        				            // echo "here";
        				            $row15=$result15->result_array();
        				            // var_dump($row15);
        				            // echo "here";
        				            foreach($row15 as $rows15)
        				            {
        				                // echo "here";
        				                $endtypeid=$rows15["id"];
        				                // echo $endtypeid;
        				                $sessionid=$_SESSION['id'];
        				                $query14="INSERT into pitch_endorsement(endorsement_id,user_id,endorsement_count,endorsment_user_id) values($endtypeid,$profile_id,1,'$sessionid')";
        				                // echo "here";
        				                if ($db->query($query14)) 
        				                {
        				                    ?>
                                            <div class="container">
                                                  <div class="alert alert-success">
                                                    <strong>Success!</strong> Player endorsed successfully in <?php echo $customfield; ?>
                                                  </div>
                                                </div>
                                            <?php
        				                }
        				                else 
                                        {
                                            echo "Error: " . $db->error;
                                        }
        				            }
        				            
        	                    }
        				        else 
                                {
                                    echo "Error: here:" . $db->error;
                                }
        				        
                            }
        				    else 
                            {
                                echo "Error: Endorsement Already exists";
                            }
                        }
                    }
                }//checkbox
                // echo $_SESSION["user_type"];
                //  echo $profile_id;
                $query="SELECT * from pitch_user where id=".$profile_id;
                
                // echo $query;
                // $result=$db->query($query); 
    //             if ($db -> connect_errno) {
    //                 echo "Failed to connect to MySQL: " . $db -> connect_error;
    //                 exit();
    //             }
    //             if ($result->num_rows() > 0) {
				//     // echo "here";
				// }
				if (!$result=$db->query($query)) {
                    echo("Error description: " . $db -> error);
                }
                // var_dump($result);
				$row = $result->row_array(); 
				// echo $row["id"];
				// echo $row["endorsment_user_id"];
				// echo $row["endorsement_count"];
				// $coachids=explode(',',$row["endorsment_user_id"]);
				// var_dump($coachids);
				$i=0;
				echo "<p style='font-size:30px;font-weight:600;'>Total Endorsement done for this player is:".$row["endorsement_count"]."</p>";
				echo "<table class='table table-hover table-striped'>";
				echo "<tr>";
				echo "<th>S.No</th>";
				echo "<th>Amount</th>";
				echo "<th>Type</th>";
				echo "<th>Coaches</th>";
				echo "<th>Image</th>";
				echo "</tr>";
				$query2="SELECT * from pitch_endorsement where user_id=".$profile_id;
				// echo $query2;
				
                if (!$result1=$db->query($query2)) {
                    echo "Error description: " . $db -> error;
                }
                // $result=$db->query($query2);
                // var_dump($result1);
                // echo "<br>";
                // echo $result->current_row;
                // // $row = $result->row_array(); 
                // $row = mysql_fetch_row($result);
                // echo $result->current_row;
                // $row = $result->row_array(); 
                // echo $row["endorsement_id"];
                // echo $_SESSION["id"];
                // $row = $result->fetch_array();
                // var_dump($row);
                // print_r($row);
                // echo $result1->num_rows();
                if ($result1->num_rows() > 0) {
                // output data of each row
                    // echo "here";
                    // foreach($x as $result1){
                   	$row = $result1->result_array();
                   	// $row=$result1->fetch_assoc();
                   	$i=1;
                    foreach($row as $rows){
                        // while($row->fetch_assoc())
                        // {
                        //     echo "<td>".$rows['endorsement_count']."</td>";
                        // }
                        // var_dump($rows);
                        
                        // echo $rows["endorsement_count"]." ";
                        // echo "here."<br>";
                        echo "<tr>"; 
                        echo "<td>$i</td>";
                        echo "<td>".$rows['endorsement_count']."</td>";
                        $query1="SELECT * from pitch_endorsement_type where id=".$rows['endorsement_id'];
                        if (!$result2=$db->query($query1)) {
                            echo("Error description: " . $db -> error);
                        }
                        $row1=$result2->result_array();
                        foreach($row1 as $rows1)
                        {
                            echo "<td>".$rows1["endorsement_name"]."</td>";
                        }
                        
                        $query3="SELECT * from pitch_user where id IN (".$rows['endorsment_user_id'].") LIMIT 10";
                        // echo $query3;
                        if (!$result3=$db->query($query3)) {
                            echo("Error description: " . $db -> error);
                        }
                        $row3=$result3->result_array();
                        $names="";
                        echo "<td>";
                        foreach ($row3 as $rows3)
                        {
                            $names=$names.$rows3["first_name"].",";
                        }
                        // $names=substr($names, 0, -1);
                        $names = rtrim($names, ", ");
                        echo $names;
                        echo "</td>";
                        $query10="SELECT * from pitch_user where id IN (".$rows['endorsment_user_id'].") LIMIT 10";
                        if (!$result10=$db->query($query10)) {
                            echo("Error description: " . $db -> error);
                        }
                        $row10=$result10->result_array();
                        echo "<td>";
                        foreach ($row10 as $rows10)
                        {
                            echo "<img width='50' height='50' src='".playerImageCheck($rows10['photo'])."'>";
                        }
                        echo "</td>";
                        // echo $query3;
                        // echo $query1;
                        // while ($row = mysqli_fetch_assoc($result1))
                        // {
                        //     echo "<td>".$row["endorsement_name"]."</td>";
                        // }   
                        // $query1="SELECT * from pitch_endorsement_type where id IN (".$row['endorsment_user_id'].")";
                        // echo $query1;
                        
                        // // echo "<td>".$row['endorsement_name']."</td>";
                        // // echo "<td>".$row['endorsement_id_names']."</td>";
                        echo "</tr>";
                        $i++;
                   }
                }
                echo "</table>";
                // echo "here";
                // while($row = $result->fetch_assoc()) 
                // {
                //     echo "here";
                //     // code
                //     echo "<tr>"; 
                //     echo "<td>".$row['endorsement_count']."</td>";
                //     $query1="SELECT * from pitch_endorsement_type where id=".$row['endorsement_id'];
                //     if (!$result1=$db->query($query1)) {
                //         echo("Error description: " . $db -> error);
                //     }
                //     // echo $query1;
                //     while ($row = mysqli_fetch_assoc($result1))
                //     {
                //         echo "<td>".$row["endorsement_name"]."</td>";
                //     }   
                //     $query1="SELECT * from pitch_endorsement_type where id IN (".$row['endorsment_user_id'].")";
                //     echo $query1;
                    
                //     // echo "<td>".$row['endorsement_name']."</td>";
                //     // echo "<td>".$row['endorsement_id_names']."</td>";
                //     echo "</tr>";
                // }
                // echo "</table>";
                // while()                                
				// echo $_SESSION['id'];
				// while($i<sizeof($coachids))
				// {
				    // $query="SELECT * from pitch_user where id=".$coachids[$i];
				    // if (!$result=$db->query($query)) {
        //                 echo("Error description: " . $db -> error);
        //             }
        //             $row = $result->row_array();
                    
				    // // echo $coachids[$i];
				    // $i++;
				// }
				// echo $_SESSION['id'];
				// while($row = mysqli_fetch_assoc($result)) {
    //                 echo "here";
    //             }
                // var_dump($result);
                
             }
             ?>
            
    <?php
        
    ?>
        </div>
        
    </div>
    
            
